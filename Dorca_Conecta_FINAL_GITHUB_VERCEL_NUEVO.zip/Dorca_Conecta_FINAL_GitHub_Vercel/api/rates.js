const https=require('https');
const ADMIN_PASSWORD='Dorca2013';
const GH_TOKEN=process.env.GITHUB_TOKEN;
const GH_REPO='carlis24680-coder/Dorca-Conect';
const GH_BRANCH='principal';
const GH_FILE='data/rates.json';
const DEFAULT={co_ve:3.95,ve_co:3,usd_colombia:3330,usd_venezuela:855.66,valid_from:'2026-10-01',valid_to:'',notes:'Tasas publicadas'};
function gh(path,opt={}){return new Promise((resolve,reject)=>{const q=https.request({hostname:'api.github.com',path,method:opt.method||'GET',headers:{'User-Agent':'Dorca-Conecta','Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28',...(GH_TOKEN?{'Authorization':'Bearer '+GH_TOKEN}:{}),...(opt.body?{'Content-Type':'application/json'}:{})}},r=>{let s='';r.on('data',c=>s+=c);r.on('end',()=>{let d={};try{d=JSON.parse(s)}catch{}resolve({status:r.statusCode,data:d})})});q.on('error',reject);if(opt.body)q.write(JSON.stringify(opt.body));q.end()})}
function out(res,status,data){res.status(status).json(data)}
module.exports=async(req,res)=>{
 try{
  if(req.method==='GET'){
   const r=await gh(`/repos/${GH_REPO}/contents/${GH_FILE}?ref=${GH_BRANCH}`);
   if(r.status===200&&r.data.content){const rate=JSON.parse(Buffer.from(r.data.content.replace(/\n/g,''),'base64').toString());return out(res,200,{rate,configured:!!GH_TOKEN})}
   return out(res,200,{rate:DEFAULT,configured:!!GH_TOKEN})
  }
  if(req.method!=='POST')return out(res,405,{error:'Método no permitido.'});
  const b=req.body||{};
  if(b.action==='login')return b.password===ADMIN_PASSWORD?out(res,200,{ok:true}):out(res,401,{error:'❌ Contraseña incorrecta. Inténtalo nuevamente.'});
  if(b.action==='save'){
   if(b.password!==ADMIN_PASSWORD)return out(res,401,{error:'❌ Contraseña incorrecta. No se publicaron cambios.'});
   if(!GH_TOKEN)return out(res,500,{error:'⚠️ Falta configurar GITHUB_TOKEN en Vercel. El administrador sí funciona, pero falta conectar el guardado público.'});
   const rate={co_ve:Number(b.rate?.coVe),ve_co:Number(b.rate?.veCo),usd_colombia:Number(b.rate?.usdColombia),usd_venezuela:Number(b.rate?.usdVenezuela),valid_from:b.rate?.validFrom||new Date().toISOString().slice(0,10),valid_to:b.rate?.validTo||'',notes:b.rate?.notes||''};
   if(!rate.co_ve||!rate.ve_co||!rate.usd_colombia||!rate.usd_venezuela)return out(res,400,{error:'Completa todas las tasas antes de publicar.'});
   const old=await gh(`/repos/${GH_REPO}/contents/${GH_FILE}?ref=${GH_BRANCH}`);
   const body={message:'Actualizar tasas publicadas Dorca Conecta',content:Buffer.from(JSON.stringify(rate,null,2)+'\n').toString('base64'),branch:GH_BRANCH};
   if(old.status===200&&old.data.sha)body.sha=old.data.sha;
   const p=await gh(`/repos/${GH_REPO}/contents/${GH_FILE}`,{method:'PUT',body});
   if(p.status<200||p.status>=300)return out(res,500,{error:'GitHub no pudo guardar la tasa. Revisa GITHUB_TOKEN en Vercel.'});
   return out(res,200,{ok:true,rate});
  }
  return out(res,400,{error:'Acción no válida.'});
 }catch(e){return out(res,500,{error:'Error del servidor.'})}
};
