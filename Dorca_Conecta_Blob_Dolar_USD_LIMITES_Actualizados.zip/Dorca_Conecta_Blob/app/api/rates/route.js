import { list, put, get } from "@vercel/blob";
import { cookies } from "next/headers";
import crypto from "node:crypto";

const PREFIX = "dorca-conecta/rates-";
const DEFAULT = {
  coVe: 3.85,
  veCo: 3.10,
  minCop: 20000,
  maxCop: 4000000,
  minBs: 5000,
  maxBs: 500000,
  // Referencias informativas del dólar (no son tasas de Dorca Conecta).
  trmColombia: 3209.78,
  compraColombia: 3190,
  ventaColombia: 3303,
  bcvVenezuela: 866.5612,
  validFrom: "2026-10-06",
  validUntil: "",
  note: "Tasas vigentes. Para realizar una operación, confirma primero por WhatsApp."
};

const ADMIN_PASSWORD = process.env.DORCA_ADMIN_PASSWORD || "Dorca2013";
const COOKIE = "dc_admin";

function token() {
  return crypto.createHash("sha256").update(ADMIN_PASSWORD).digest("hex");
}

async function readRates() {
  try {
    const result = await list({ prefix: PREFIX });
    const blobs = (result?.blobs || []).sort(
      (a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt)
    );
    if (!blobs.length) return DEFAULT;

    const latest = blobs[0];

    // Public Blob: direct URL works.
    try {
      const response = await fetch(latest.url, { cache: "no-store" });
      if (response.ok) return { ...DEFAULT, ...(await response.json()) };
    } catch {}

    // Private Blob: use the authenticated SDK. This also works with OIDC.
    const pathname = latest.pathname || latest.url.split("/").pop();
    const privateBlob = await get(pathname, { access: "private", useCache: false });
    if (privateBlob?.stream) {
      const text = await new Response(privateBlob.stream).text();
      return { ...DEFAULT, ...JSON.parse(text) };
    }

    return DEFAULT;
  } catch (error) {
    console.error("Blob read error:", error);
    return DEFAULT;
  }
}

export async function GET() {
  const data = await readRates();
  return Response.json(data, {
    headers: { "Cache-Control": "no-store, max-age=0" }
  });
}

export async function PUT(request) {
  const jar = await cookies();
  const auth = jar.get(COOKIE)?.value;
  if (!auth || auth !== token()) {
    return Response.json({ error: "No autorizado." }, { status: 401 });
  }

  try {
    const incoming = await request.json();
    const data = {
      ...DEFAULT,
      ...incoming,
      coVe: Number(incoming.coVe),
      veCo: Number(incoming.veCo),
      minCop: Number(incoming.minCop),
      maxCop: Number(incoming.maxCop),
      minBs: Number(incoming.minBs),
      maxBs: Number(incoming.maxBs),
      trmColombia: Number(incoming.trmColombia),
      compraColombia: Number(incoming.compraColombia),
      ventaColombia: Number(incoming.ventaColombia),
      bcvVenezuela: Number(incoming.bcvVenezuela)
    };

    if (![data.coVe, data.veCo, data.minCop, data.maxCop, data.minBs, data.maxBs, data.trmColombia, data.compraColombia, data.ventaColombia, data.bcvVenezuela].every(Number.isFinite)) {
      return Response.json({ error: "Hay un valor numérico inválido." }, { status: 400 });
    }
    if (data.coVe <= 0 || data.veCo <= 0 || data.minCop <= 0 || data.maxCop < data.minCop || data.minBs <= 0 || data.maxBs < data.minBs || data.trmColombia <= 0 || data.compraColombia <= 0 || data.ventaColombia <= 0 || data.bcvVenezuela <= 0) {
      return Response.json({ error: "Revisa las tasas y los límites." }, { status: 400 });
    }

    // A new pathname avoids CDN/cache issues after each publication.
    const pathname = `${PREFIX}${Date.now()}.json`;
    const body = JSON.stringify(data, null, 2);

    let saved = false;
    let lastError = null;

    // Works with a public Blob store.
    try {
      await put(pathname, body, {
        access: "public",
        addRandomSuffix: false,
        contentType: "application/json"
      });
      saved = true;
    } catch (error) {
      lastError = error;
    }

    // If the connected store is private, use private Blob instead.
    if (!saved) {
      try {
        await put(pathname, body, {
          access: "private",
          addRandomSuffix: false,
          contentType: "application/json"
        });
        saved = true;
      } catch (error) {
        lastError = error;
      }
    }

    if (!saved) {
      console.error("Blob write error:", lastError);
      const detail = lastError?.message ? ` ${lastError.message}` : "";
      return Response.json({ error: `No se pudo guardar en Vercel Blob.${detail}` }, { status: 500 });
    }

    return Response.json({ ok: true, data });
  } catch (error) {
    console.error("Rates error:", error);
    return Response.json({ error: "No se pudo guardar la información." }, { status: 500 });
  }
}
