import { cookies } from "next/headers";
import crypto from "node:crypto";

const ADMIN_PASSWORD = process.env.DORCA_ADMIN_PASSWORD || "Dorca2013";
const COOKIE = "dc_admin";

function token() {
  return crypto.createHash("sha256").update(ADMIN_PASSWORD).digest("hex");
}

export async function POST(request) {
  const body = await request.json().catch(() => ({}));
  if (body.password !== ADMIN_PASSWORD) {
    return Response.json({ error: "Contraseña incorrecta." }, { status: 401 });
  }

  const jar = await cookies();
  jar.set(COOKIE, token(), {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7
  });

  return Response.json({ ok: true });
}
