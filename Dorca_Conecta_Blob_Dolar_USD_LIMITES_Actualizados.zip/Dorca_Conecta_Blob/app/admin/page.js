 "use client";

import { useEffect, useState } from "react";

const DEFAULT = {
  coVe: 3.85,
  veCo: 3.10,
  minCop: 20000,
  maxCop: 4000000,
  minBs: 5000,
  maxBs: 500000,
  trmColombia: 3209.78,
  compraColombia: 3190,
  ventaColombia: 3303,
  bcvVenezuela: 866.5612,
  validFrom: "2026-10-06",
  validUntil: "",
  note: "Tasas vigentes. Para realizar una operación, confirma primero por WhatsApp."
};

export default function Admin() {
  const [password, setPassword] = useState("");
  const [logged, setLogged] = useState(false);
  const [data, setData] = useState(DEFAULT);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/rates", { cache: "no-store" })
      .then(r => r.json())
      .then(d => setData({ ...DEFAULT, ...d }));
  }, []);

  async function login(e) {
    e.preventDefault();
    setMsg("");
    const r = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password })
    });
    if (r.ok) {
      setLogged(true);
      setMsg("Acceso correcto.");
    } else {
      setMsg("Contraseña incorrecta.");
    }
  }

  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setMsg("");
    const r = await fetch("/api/rates", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const body = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) {
      setMsg(body.error || "No se pudo publicar la información.");
      return;
    }
    setData({ ...data, ...body.data });
    setMsg("✓ Información publicada correctamente. Los clientes verán la actualización.");
  }

  if (!logged) {
    return (
      <main className="admin-page">
        <div className="admin-box login-box">
          <img src="/logo.png" className="admin-logo" alt="Dorca Conecta" />
          <h1>Administrador</h1>
          <p>Acceso privado para actualizar tasas y referencias.</p>
          <form onSubmit={login}>
            <label>Contraseña</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Contraseña" autoFocus />
            <button>Entrar</button>
          </form>
          {msg && <div className={msg.includes("incorrecta") ? "error" : "notice"}>{msg}</div>}
          <a href="/">← Volver a la calculadora</a>
        </div>
      </main>
    );
  }

  return (
    <main className="admin-page">
      <div className="admin-box">
        <img src="/logo.png" className="admin-logo" alt="Dorca Conecta" />
        <h1>Panel privado</h1>
        <p>Los datos se guardan en <b>Vercel Blob</b>. No usa Redis, Supabase, Neon ni GitHub.</p>

        <form onSubmit={save} className="admin-form">
          <h3>Tasas de Dorca Conecta</h3>
          <div className="two">
            <label>Colombia → Venezuela
              <input type="number" step="0.01" value={data.coVe} onChange={e => setData({...data, coVe: e.target.value})}/>
            </label>
            <label>Venezuela → Colombia
              <input type="number" step="0.01" value={data.veCo} onChange={e => setData({...data, veCo: e.target.value})}/>
            </label>
          </div>
          <p className="admin-help">Estas son las tasas de tus operaciones. No son las referencias de compra/venta del dólar.</p>

          <h3>🇨🇴 Referencias del dólar en Colombia</h3>
          <div className="three">
            <label>TRM
              <input type="number" step="0.01" value={data.trmColombia} onChange={e => setData({...data, trmColombia: e.target.value})}/>
            </label>
            <label>Compra
              <input type="number" step="0.01" value={data.compraColombia} onChange={e => setData({...data, compraColombia: e.target.value})}/>
            </label>
            <label>Venta
              <input type="number" step="0.01" value={data.ventaColombia} onChange={e => setData({...data, ventaColombia: e.target.value})}/>
            </label>
          </div>
          <p className="admin-help">Son referencias informativas de Colombia. No representan compra/venta de divisas de Dorca Conecta.</p>

          <h3>🇻🇪 Referencia del dólar BCV</h3>
          <label>Dólar BCV (Bs por USD)
            <input type="number" step="0.0001" value={data.bcvVenezuela} onChange={e => setData({...data, bcvVenezuela: e.target.value})}/>
          </label>
          <p className="admin-help">Se utiliza para calcular el equivalente aproximado en USD de lo recibido en Venezuela.</p>

          <h3>Límites de Colombia → Venezuela</h3>
          <div className="two">
            <label>Mínimo COP<input type="number" value={data.minCop} onChange={e => setData({...data, minCop: e.target.value})}/></label>
            <label>Máximo COP<input type="number" value={data.maxCop} onChange={e => setData({...data, maxCop: e.target.value})}/></label>
          </div>

          <h3>Límites de Venezuela → Colombia</h3>
          <div className="two">
            <label>Mínimo Bs<input type="number" value={data.minBs} onChange={e => setData({...data, minBs: e.target.value})}/></label>
            <label>Máximo Bs<input type="number" value={data.maxBs} onChange={e => setData({...data, maxBs: e.target.value})}/></label>
          </div>

          <h3>Fecha e información para clientes</h3>
          <div className="two">
            <label>Fecha de referencia<input type="date" value={data.validFrom} onChange={e => setData({...data, validFrom: e.target.value})}/></label>
            <label>Hasta (opcional)<input type="date" value={data.validUntil} onChange={e => setData({...data, validUntil: e.target.value})}/></label>
          </div>
          <label>Mensaje público<textarea rows="4" value={data.note} onChange={e => setData({...data, note: e.target.value})}/></label>

          <button className="publish" disabled={busy}>{busy ? "Publicando…" : "PUBLICAR ACTUALIZACIÓN"}</button>
        </form>

        {msg && <div className={msg.startsWith("✓") ? "notice" : "error"}>{msg}</div>}
        <a href="/">← Ver página pública</a>
      </div>
    </main>
  );
}
