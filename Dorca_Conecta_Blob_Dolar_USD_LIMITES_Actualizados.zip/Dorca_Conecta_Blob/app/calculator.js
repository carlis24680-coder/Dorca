 "use client";

import { useEffect, useMemo, useState } from "react";

const FALLBACK = {
  coVe: 3.85,
  veCo: 3.10,
  minCop: 20000,
  maxCop: 4000000,
  minBs: 5000,
  maxBs: 500000,
  trmColombia: 3209.78,
  compraColombia: 3190,
  ventaColombia: 3303,
  bcvVenezuela: 866.5612,
  validFrom: "2026-10-06",
  validUntil: "",
  note: "Tasas vigentes. Para realizar una operación, confirma primero por WhatsApp."
};

const moneyCOP = new Intl.NumberFormat("es-CO", { maximumFractionDigits: 0 });
const moneyBs = new Intl.NumberFormat("es-VE", { maximumFractionDigits: 2 });
const moneyUSD = new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function fmt(value, currency) {
  if (!Number.isFinite(value)) return "—";
  if (currency === "COP") return `$ ${moneyCOP.format(value)} COP`;
  if (currency === "USD") return `US$ ${moneyUSD.format(value)}`;
  return `${moneyBs.format(value)} Bs`;
}

function todayText() {
  return new Intl.DateTimeFormat("es-CO", {
    day: "2-digit", month: "2-digit", year: "numeric"
  }).format(new Date());
}

function referenceDate(value) {
  if (!value) return "—";
  const parts = String(value).split("-");
  if (parts.length !== 3) return value;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

export default function Calculator() {
  const [rates, setRates] = useState(FALLBACK);
  const [loading, setLoading] = useState(true);
  const [direction, setDirection] = useState("coVe");
  const [mode, setMode] = useState("send");
  const [amount, setAmount] = useState("");

  useEffect(() => {
    fetch("/api/rates", { cache: "no-store" })
      .then(r => r.json())
      .then(data => setRates({ ...FALLBACK, ...data }))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const rate = direction === "coVe" ? Number(rates.coVe) : Number(rates.veCo);

  const result = useMemo(() => {
    const n = Number(String(amount).replace(",", "."));
    if (!Number.isFinite(n) || n <= 0) {
      return { value: 0, send: 0, receive: 0, usd: 0, error: "" };
    }

    if (direction === "coVe") {
      if (mode === "send") {
        const receive = n / rate;
        const usd = receive / Number(rates.bcvVenezuela);
        return {
          value: receive, send: n, receive, usd,
          error: n < rates.minCop || n > rates.maxCop
            ? `El envío debe estar entre ${fmt(rates.minCop, "COP")} y ${fmt(rates.maxCop, "COP")}.`
            : ""
        };
      }
      const send = n * rate;
      const usd = n / Number(rates.bcvVenezuela);
      return {
        value: send, send, receive: n, usd,
        error: send < rates.minCop || send > rates.maxCop
          ? `Para recibir esa cantidad, el envío debe quedar entre ${fmt(rates.minCop, "COP")} y ${fmt(rates.maxCop, "COP")}.`
          : ""
      };
    }

    if (mode === "send") {
      const receive = n * rate;
      const usd = receive / Number(rates.trmColombia);
      return {
        value: receive, send: n, receive, usd,
        error: n < rates.minBs || n > rates.maxBs
          ? `El envío debe estar entre ${fmt(rates.minBs, "Bs")} y ${fmt(rates.maxBs, "Bs")}.`
          : ""
      };
    }

    const send = n / rate;
    const usd = n / Number(rates.trmColombia);
    return {
      value: send, send, receive: n, usd,
      error: send < rates.minBs || send > rates.maxBs
        ? `Para recibir esa cantidad, el envío debe quedar entre ${fmt(rates.minBs, "Bs")} y ${fmt(rates.maxBs, "Bs")}.`
        : ""
    };
  }, [amount, direction, mode, rate, rates]);

  const inputCurrency = direction === "coVe"
    ? (mode === "send" ? "COP" : "Bs")
    : (mode === "send" ? "Bs" : "COP");

  const outputCurrency = inputCurrency === "COP" ? "Bs" : "COP";

  const whatsapp = () => {
    const dirText = direction === "coVe" ? "Colombia → Venezuela" : "Venezuela → Colombia";
    const objective = mode === "send"
      ? `Enviar ${fmt(result.send, inputCurrency)}`
      : `Quiero recibir ${fmt(result.receive, outputCurrency)}`;
    const calc = result.value
      ? `Resultado: ${fmt(result.value, outputCurrency)}`
      : "Aún no he colocado el monto.";
    const text = `Hola Dorca Conecta. Deseo realizar una operación ${dirText}. ${objective}. ${calc}. Tasa: ${rate}.`;
    window.open(`https://wa.me/573019211382?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <main className="page">
      <header className="hero">
        <img src="/logo.png" alt="Dorca Conecta" className="logo" />
        <div>
          <p className="eyebrow">DORCA CONECTA</p>
          <h1>Calculadora Colombia ↔ Venezuela</h1>
          <p className="subtitle">Tu cambio, nuestra conexión.</p>
        </div>
      </header>

      <section className="rate-grid">
        <article className="rate-card">
          <span>🇨🇴 Colombia → 🇻🇪 Venezuela</span>
          <strong>{rateFor(rates.coVe)} Bs por cada COP</strong>
          <small>Se calcula COP ÷ tasa = bolívares</small>
        </article>
        <article className="rate-card">
          <span>🇻🇪 Venezuela → 🇨🇴 Colombia</span>
          <strong>{rateFor(rates.veCo)} COP por cada Bs</strong>
          <small>Se calcula Bs × tasa = pesos</small>
        </article>
      </section>

      <section className="dollar-grid">
        <article className="dollar-card">
          <div className="card-heading">
            <div>
              <span className="eyebrow small">REFERENCIAS INFORMATIVAS</span>
              <h2>🇨🇴 Dólar en Colombia</h2>
            </div>
            <span className="date-chip">{referenceDate(rates.validFrom)}</span>
          </div>
          <div className="dollar-values">
            <div><span>TRM</span><strong>$ {moneyCOP.format(Number(rates.trmColombia))}</strong></div>
            <div><span>Compra</span><strong>$ {moneyCOP.format(Number(rates.compraColombia))}</strong></div>
            <div><span>Venta</span><strong>$ {moneyCOP.format(Number(rates.ventaColombia))}</strong></div>
          </div>
          <p className="reference-note">Referencias informativas. No corresponden a compra o venta de divisas de Dorca Conecta.</p>
        </article>

        <article className="dollar-card">
          <div className="card-heading">
            <div>
              <span className="eyebrow small">REFERENCIA INFORMATIVA</span>
              <h2>🇻🇪 Dólar BCV</h2>
            </div>
            <span className="date-chip">{referenceDate(rates.validFrom)}</span>
          </div>
          <div className="bcv-value">
            <span>1 USD =</span>
            <strong>{moneyBs.format(Number(rates.bcvVenezuela))} Bs</strong>
          </div>
          <p className="reference-note">Se utiliza para mostrar el equivalente en dólares del monto recibido en Venezuela.</p>
        </article>
      </section>

      <section className="calculator">
        <div className="section-title">
          <span className="badge">CALCULADORA</span>
          <span>{loading ? "Actualizando tasas…" : `Actualizada ${todayText()}`}</span>
        </div>

        <div className="direction-tabs">
          <button className={direction === "coVe" ? "active" : ""} onClick={() => {setDirection("coVe"); setAmount("");}}>
            🇨🇴 Colombia → 🇻🇪 Venezuela
          </button>
          <button className={direction === "veCo" ? "active" : ""} onClick={() => {setDirection("veCo"); setAmount("");}}>
            🇻🇪 Venezuela → 🇨🇴 Colombia
          </button>
        </div>

        <div className="mode-tabs">
          <button className={mode === "send" ? "active" : ""} onClick={() => {setMode("send"); setAmount("");}}>Quiero enviar</button>
          <button className={mode === "receive" ? "active" : ""} onClick={() => {setMode("receive"); setAmount("");}}>Quiero recibir</button>
        </div>

        <label className="field">
          <span>{mode === "send" ? `¿Cuánto vas a enviar en ${inputCurrency}?` : `¿Cuánto quieres recibir en ${outputCurrency === "Bs" ? "bolívares" : "pesos colombianos"}?`}</span>
          <input
            inputMode="decimal"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            placeholder={inputCurrency === "COP" ? "Ej. 200.000" : "Ej. 50.000"}
          />
        </label>

        <div className="result">
          <span>{mode === "send" ? "El cliente recibe" : "Debes enviar"}</span>
          <strong>{fmt(result.value, outputCurrency)}</strong>
          {result.value > 0 && (
            <div className="usd-result">
              <span>💵 Equivalente aproximado en dólares</span>
              <b>{fmt(result.usd, "USD")}</b>
              <small>
                {direction === "coVe"
                  ? `Calculado con dólar BCV: ${moneyBs.format(Number(rates.bcvVenezuela))} Bs/USD`
                  : `Calculado con TRM Colombia: $ ${moneyCOP.format(Number(rates.trmColombia))} COP/USD`}
              </small>
            </div>
          )}
          <p>
            Tasa Dorca Conecta aplicada: <b>{rate}</b> · {direction === "coVe" ? "COP ÷ tasa" : "Bs × tasa"}
          </p>
        </div>

        {result.error && <div className="error">{result.error}</div>}

        <button className="whatsapp" onClick={whatsapp}>
          💬 Continuar esta operación por WhatsApp
        </button>
      </section>

      <section className="info-grid">
        <div><b>✓ Claro</b><span>Consulta cuánto envías, recibes y su equivalente aproximado en USD.</span></div>
        <div><b>⚡ Rápido</b><span>Calcula tu operación en segundos.</span></div>
        <div><b>🤝 Confiable</b><span>Confirma siempre la tasa vigente antes de operar.</span></div>
      </section>

      <footer>
        <p>{rates.note}</p>
        <p>Vigencia: {rates.validFrom || "—"} {rates.validUntil ? `al ${rates.validUntil}` : ""}</p>
        {/* Acceso administrador deliberadamente oculto. Se conserva la ruta /admin para la administradora. */}
      </footer>
    </main>
  );
}

function rateFor(n) {
  return Number(n).toLocaleString("es-CO", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
