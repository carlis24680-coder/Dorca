import "./globals.css";

export const metadata = {
  title: "Dorca Conecta | Calculadora de cambios",
  description: "Calculadora profesional Colombia ↔ Venezuela de Dorca Conecta."
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
