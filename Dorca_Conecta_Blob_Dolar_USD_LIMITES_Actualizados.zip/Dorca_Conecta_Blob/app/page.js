import Calculator from "./calculator";

export const dynamic = "force-dynamic";

export default function Home() {
  return <Calculator />;
}
