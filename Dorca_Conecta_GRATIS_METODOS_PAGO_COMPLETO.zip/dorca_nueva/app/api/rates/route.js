import { put, list, get } from '@vercel/blob';
import { NextResponse } from 'next/server';

const PREFIX = 'dorca-conecta/';
const DEFAULTS = {
  coToVe: 3.85,
  veToCo: 3.00,
  trm: 3330,
  bcv: 855.66,
  euro: 3900,
  usdt: 3400,
  updatedAt: new Date().toISOString(),
  message: 'Tasas Dorca Conecta'
};

async function getRates() {
  try {
    const { blobs } = await list({
      prefix: PREFIX,
      token: process.env.BLOB_READ_WRITE_TOKEN,
      limit: 100
    });

    if (!blobs || blobs.length === 0) return DEFAULTS;

    const ratesBlobs = blobs.filter((b) => b.pathname.endsWith('.json'));
    if (!ratesBlobs.length) return DEFAULTS;

    ratesBlobs.sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
    const latest = ratesBlobs[0];

    // The connected Blob store is PRIVATE, so read the file through
    // the authenticated SDK instead of fetching its public URL.
    const result = await get(latest.pathname, {
      access: 'private',
      useCache: false,
      token: process.env.BLOB_READ_WRITE_TOKEN
    });

    if (!result) return DEFAULTS;

    const text = await new Response(result.stream).text();
    const saved = JSON.parse(text);
    return { ...DEFAULTS, ...saved };
  } catch (error) {
    console.error('GET /api/rates error:', error);
    return DEFAULTS;
  }
}

export async function GET() {
  return NextResponse.json(await getRates(), {
    headers: { 'Cache-Control': 'no-store, max-age=0' }
  });
}

export async function POST(req) {
  try {
    const body = await req.json();

    const password = String(body.password || '');
    const expected = process.env.ADMIN_PASSWORD || 'Dorca2013';

    if (password !== expected) {
      return NextResponse.json(
        { ok: false, error: 'Contraseña incorrecta.' },
        { status: 401 }
      );
    }

    if (!process.env.BLOB_READ_WRITE_TOKEN) {
      return NextResponse.json(
        { ok: false, error: 'Falta BLOB_READ_WRITE_TOKEN en este despliegue.' },
        { status: 500 }
      );
    }

    const rates = {
      coToVe: Number(body.coToVe),
      veToCo: Number(body.veToCo),
      trm: Number(body.trm),
      bcv: Number(body.bcv),
      euro: Number(body.euro),
      usdt: Number(body.usdt),
      updatedAt: new Date().toISOString(),
      message: String(body.message || '')
    };

    const values = Object.values(rates).slice(0, 6);
    if (values.some((v) => !Number.isFinite(v) || v <= 0)) {
      return NextResponse.json(
        { ok: false, error: 'Revisa las tasas ingresadas.' },
        { status: 400 }
      );
    }

    const pathname = `${PREFIX}rates-${Date.now()}.json`;

    // IMPORTANT: the existing Blob store is PRIVATE.
    await put(pathname, JSON.stringify(rates), {
      access: 'private',
      addRandomSuffix: false,
      contentType: 'application/json',
      token: process.env.BLOB_READ_WRITE_TOKEN
    });

    return NextResponse.json({ ok: true, rates });
  } catch (error) {
    console.error('POST /api/rates error:', error);
    return NextResponse.json(
      {
        ok: false,
        error: `No se pudieron publicar las tasas. ${error?.message || ''}`.trim()
      },
      { status: 500 }
    );
  }
}
