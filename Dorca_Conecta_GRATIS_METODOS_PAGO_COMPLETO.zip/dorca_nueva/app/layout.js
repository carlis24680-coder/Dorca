import './globals.css';
export const metadata={title:'Dorca Conecta | Calculadora',description:'Calculadora profesional Colombia ↔ Venezuela'};
export default function RootLayout({children}){return <html lang="es"><body>{children}</body></html>}
